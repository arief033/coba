#!/bin/sh

ln -s /opt/vc/lib/libbrcmGLESv2.so /opt/vc/lib/libGLESv2.so
ln -s /opt/vc/lib/libEGL.so /opt/vc/lib/libEGL.so.1
ln -s /opt/vc/lib/libGLESv2.so /usr/lib/arm-linux-gnueabihf/libGLESv2.so

sed 's?PWD?'`pwd`'?' sultan.desktop > /etc/xdg/autostart/sultan.desktop
sed 's?PWD?'`pwd`'?' sultan.desktop > /usr/share/applications/sultan.desktop
#echo 'i2c-brcm2708' >> /etc/modules
#echo 'rtc-ds1307' >> /etc/modules
#echo 'dtoverlay=i2c-rtc,ds1307' >> /boot/config.txt
lxpanelctl restart
